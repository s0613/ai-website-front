# 🚀 배포 가이드

## 비디오 생성 워커 설정

### 1. 필수 환경 변수
```bash
# Redis 연결 URL
REDIS_URL=redis://localhost:6379

# 내부 API 토큰
INTERNAL_API_TOKEN=your_internal_token_here

# FAL API 키
FAL_KEY=your_fal_api_key_here
```

### 2. 워커 실행 (프로덕션)
```bash
# 메인 애플리케이션과 별도로 실행해야 함
npm run worker

# 또는 PM2 사용 시
pm2 start "npm run worker" --name "video-worker"
```

### 3. 워커 상태 확인
```bash
# PM2로 관리하는 경우
pm2 list
pm2 logs video-worker

# 직접 실행하는 경우 콘솔에서 확인
# "✅ video-generation worker started" 메시지 확인
```

### 4. 문제 해결

#### 알림 상태가 업데이트되지 않는 경우
1. 워커가 실행 중인지 확인
2. Redis 연결 상태 확인
3. INTERNAL_API_TOKEN 설정 확인
4. 워커 로그에서 에러 메시지 확인

#### 지원되는 모델
- ✅ **Kling**: 완전 지원
- ⚠️ **Veo2, Hunyuan, Wan**: 구현 중 (에러 메시지와 함께 FAILED 상태로 처리)

### 5. 모니터링
워커 로그에서 다음 메시지들을 확인하세요:
- `✅ 작업 완료: kling (jobId: xxx)`
- `❌ 작업 실패: veo2 (jobId: xxx)`
- `✅ 알림 상태 FAILED로 업데이트 완료`
- `❌ 알림 상태 업데이트 실패` 