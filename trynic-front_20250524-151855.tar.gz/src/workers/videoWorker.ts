// src/workers/videoWorker.ts

import 'dotenv/config';
import { Worker, Job } from 'bullmq';
import { saveVideoFromUrl } from '@/app/internal/video/services/VideoStorageService';
import type { VideoJobData } from '@/app/internal/video/services/VideoQueueService';
import { NotificationUpdateService } from '@/app/internal/video/services/NotificationUpdateService';
import { fal } from '@fal-ai/client';

interface KlingVideoOutput {
    video: {
        url: string;
        content_type?: string;
        file_name?: string;
        file_size?: number;
    };
}

interface GenericVideoOutput {
    video: {
        url: string;
    };
}

interface VideoGenerationInput {
    prompt: string;
    image_url: string;
    duration?: number | string;
    aspect_ratio?: string;
    [key: string]: unknown;
}

const connection = { url: process.env.REDIS_URL ?? 'redis://localhost:6379' };
const QUEUE_NAME = 'video-generation';

const worker = new Worker<VideoJobData>(
    QUEUE_NAME,
    async (job: Job<VideoJobData>) => {
        const { type, prompt, imageUrl, duration, aspect_ratio, camera_control, userId, notificationId } = job.data;
        let generatedUrl: string;
        let modelName: string;

        try {
            switch (type) {
                case 'kling':
                    const klingRes = await fal.subscribe(
                        'fal-ai/kling-video/v1.6/pro/image-to-video',
                        {
                            input: {
                                prompt,
                                image_url: imageUrl,
                                duration: duration === '10' ? '10' : '5',
                                aspect_ratio:
                                    aspect_ratio === '1:1'
                                        ? '1:1'
                                        : aspect_ratio === '9:16'
                                            ? '9:16'
                                            : '16:9',
                            },
                            logs: true,
                        }
                    );
                    generatedUrl = (klingRes.data as KlingVideoOutput).video.url;
                    modelName = 'kling-video-v1.6';
                    break;

                case 'veo2':
                    throw new Error('Veo2 모델은 현재 구현 중입니다. 잠시 후 다시 시도해주세요.');

                case 'hunyuan':
                    throw new Error('Hunyuan 모델은 현재 구현 중입니다. 잠시 후 다시 시도해주세요.');

                case 'wan':
                    throw new Error('Wan 모델은 현재 구현 중입니다. 잠시 후 다시 시도해주세요.');

                default:
                    throw new Error(`지원하지 않는 작업 타입: ${type}`);
            }

            const saved = await saveVideoFromUrl({
                prompt,
                endpoint: type,
                model: modelName,
                videoName: `${type}-${Date.now()}.mp4`,
                videoUrl: generatedUrl,
                userId,
                notificationId: notificationId ? parseInt(notificationId) : undefined,
                activeTab: 'image',
            });

            return saved;
        } catch (error) {
            console.error(`[${type}] 비디오 생성 실패:`, error);

            // 실패 시 알림 상태 업데이트
            if (notificationId && userId) {
                try {
                    await NotificationUpdateService.updateNotification(parseInt(notificationId), {
                        status: 'FAILED',
                        errorMessage: error instanceof Error ? error.message : '비디오 생성 중 오류가 발생했습니다.',
                        userId: userId
                    });
                    console.log(`[${type}] 알림 상태 FAILED로 업데이트 완료`);
                } catch (updateError) {
                    console.error(`[${type}] 알림 상태 업데이트 실패:`, updateError);
                }
            }

            throw error;
        }
    },
    {
        connection,
        concurrency: 3,
    },
);

worker.on('completed', (job) => {
    console.log(`✅ 작업 완료: ${job.data.type} (jobId: ${job.id})`);
});

worker.on('failed', (job, err) => {
    console.error(`❌ 작업 실패: ${job?.data?.type || 'unknown'} (jobId: ${job?.id || 'unknown'})`, err.message);
});

console.log('✅ video-generation worker started');
