"use client";
import React from "react";
import ImageUpload from "@/features/image/components/upload/ImageUploader";

const ImageUploadPage = () => {
  return <ImageUpload />;
};

export default ImageUploadPage;
