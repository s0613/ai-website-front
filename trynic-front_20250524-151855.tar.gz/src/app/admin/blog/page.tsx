"use client";
import React from "react";
import BlogForm from "@/features/blog/BlogForm";

const BlogFormPage = () => {
  return <BlogForm />;
};

export default BlogFormPage;
