import { NextResponse } from "next/server";
import { addVideoJob, getJobStatus } from '@/app/internal/video/services/VideoQueueService';

interface WanRequest {
    prompt: string;
    imageUrl: string;
    numFrames?: number;
    framesPerSecond?: number;
    seed?: number;
    resolution?: string;
    numInferenceSteps?: number;
    enableSafetyChecker?: boolean;
    enablePromptExpansion?: boolean;
    userId: string;
    notificationId?: string;
}

export async function POST(req: Request) {
    try {
        const body = await req.json() as WanRequest;
        const {
            prompt,
            imageUrl,
            numFrames = 81,
            framesPerSecond = 16,
            seed,
            resolution = "720p",
            numInferenceSteps = 30,
            enableSafetyChecker = true,
            enablePromptExpansion = true,
            userId,
            notificationId
        } = body;

        // 필수 파라미터 검증
        const missingParams = [];
        if (!prompt) missingParams.push('prompt');
        if (!imageUrl) missingParams.push('imageUrl');
        if (!userId) missingParams.push('userId');

        if (missingParams.length > 0) {
            console.error('[WAN] 필수 파라미터 누락:', missingParams);
            return NextResponse.json(
                {
                    error: "필수 파라미터가 누락되었습니다.",
                    missingParams
                },
                { status: 400 }
            );
        }

        // 작업을 큐에 추가
        const jobId = await addVideoJob('wan', {
            type: 'wan',
            prompt,
            imageUrl,
            numFrames,
            framesPerSecond,
            seed,
            resolution,
            numInferenceSteps,
            enableSafetyChecker,
            enablePromptExpansion,
            userId,
            notificationId
        });

        return NextResponse.json({
            jobId,
            status: 'queued'
        }, { status: 202 });

    } catch (error) {
        console.error('[WAN] 영상 생성 오류:', error);
        return NextResponse.json(
            {
                error: error instanceof Error ? error.message : "영상 생성 중 오류 발생",
                details: error instanceof Error ? error.stack : undefined
            },
            { status: 500 }
        );
    }
}

export async function GET(req: Request) {
    const { searchParams } = new URL(req.url);
    const jobId = searchParams.get('jobId');
    if (!jobId) return NextResponse.json({ error: 'jobId required' }, { status: 400 });

    console.log('[WAN] 상태 확인 요청:', { jobId });
    const status = await getJobStatus(jobId);
    return NextResponse.json(status, { status: 200 });
} 