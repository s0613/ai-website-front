import { NextRequest, NextResponse } from "next/server";
import { addVideoJob, getJobStatus } from '@/app/internal/video/services/VideoQueueService';

interface HunyuanRequest {
    prompt: string;
    image_url: string;
    seed?: number;
    aspect_ratio?: "16:9" | "9:16";
    resolution?: "512p" | "720p";
    num_frames?: number;
    i2v_stability?: boolean;
    negative_prompt?: string;
    num_inference_steps?: number;
    fps?: number;
    cfg_scale?: number;
    enable_prompt_expansion?: boolean;
    enable_safety_checker?: boolean;
    userId: string;
    notificationId?: string;
}

export async function POST(req: NextRequest) {
    try {
        // 런타임에 환경 변수 확인
        if (!process.env.FAL_KEY) {
            return NextResponse.json(
                {
                    error: "FAL_KEY 환경 변수가 설정되지 않았습니다.",
                },
                { status: 500 }
            );
        }

        const body = await req.json() as HunyuanRequest;
        const {
            prompt,
            image_url,
            seed,
            aspect_ratio = "16:9",
            resolution = "720p",
            num_frames = 129,
            i2v_stability = false,
            negative_prompt,
            num_inference_steps = 30,
            fps = 25,
            cfg_scale = 7.5,
            enable_prompt_expansion = true,
            enable_safety_checker = true,
            userId,
            notificationId
        } = body;

        // 필수 파라미터 검증
        const missingParams = [];
        if (!prompt) missingParams.push('prompt');
        if (!image_url) missingParams.push('image_url');
        if (!userId) missingParams.push('userId');

        if (missingParams.length > 0) {
            console.error('[Hunyuan] 필수 파라미터 누락:', missingParams);
            return NextResponse.json(
                {
                    error: "필수 파라미터가 누락되었습니다.",
                    missingParams
                },
                { status: 400 }
            );
        }

        // 작업을 큐에 추가
        const jobId = await addVideoJob('hunyuan', {
            type: 'hunyuan',
            prompt,
            imageUrl: image_url,
            seed,
            aspect_ratio,
            resolution,
            num_frames,
            i2v_stability,
            negative_prompt,
            num_inference_steps,
            fps,
            cfg_scale,
            enable_prompt_expansion,
            enable_safety_checker,
            userId,
            notificationId
        });

        return NextResponse.json({
            jobId,
            status: 'queued'
        }, { status: 202 });

    } catch (error) {
        console.error('[Hunyuan] 영상 생성 오류:', error);
        return NextResponse.json(
            {
                error: error instanceof Error ? error.message : "영상 생성 중 오류 발생",
                details: error instanceof Error ? error.stack : undefined
            },
            { status: 500 }
        );
    }
}

export async function GET(req: NextRequest) {
    const { searchParams } = new URL(req.url);
    const jobId = searchParams.get('jobId');
    if (!jobId) return NextResponse.json({ error: 'jobId required' }, { status: 400 });

    console.log('[Hunyuan] 상태 확인 요청:', { jobId });
    const status = await getJobStatus(jobId);
    return NextResponse.json(status, { status: 200 });
} 