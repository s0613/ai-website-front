/* …생략: import, validation 등 기존 코드 … */

import { NextResponse } from "next/server";
import { addVideoJob, getJobStatus } from '@/app/internal/video/services/VideoQueueService';

export async function POST(req: Request) {
    try {
        const body = await req.json();
        const { prompt, imageUrl, aspect_ratio, duration, notificationId, userId } = body;

        if (!prompt || !imageUrl) {
            return NextResponse.json(
                { error: "프롬프트와 이미지 URL이 필요합니다." },
                { status: 400 }
            );
        }

        // 작업을 큐에 추가
        const jobId = await addVideoJob('veo2', {
            type: 'veo2',
            prompt,
            imageUrl,
            aspect_ratio,
            duration,
            notificationId,
            userId
        });

        return NextResponse.json({
            jobId,
            status: 'queued'
        }, { status: 202 });

    } catch (error) {
        console.error('[Veo2] 영상 생성 오류:', error);
        return NextResponse.json(
            { error: error instanceof Error ? error.message : "영상 생성 중 오류 발생" },
            { status: 500 }
        );
    }
}

export async function GET(req: Request) {
    const { searchParams } = new URL(req.url);
    const jobId = searchParams.get('jobId');
    if (!jobId) return NextResponse.json({ error: 'jobId required' }, { status: 400 });

    console.log('[Veo2] 상태 확인 요청:', { jobId });
    const status = await getJobStatus(jobId);
    return NextResponse.json(status, { status: 200 });
}
