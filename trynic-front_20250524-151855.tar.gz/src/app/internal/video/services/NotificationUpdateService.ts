import apiClient from '@/lib/api/apiClient';

/* ------------------------------------------------------------------
 * 타입 정의
 * ------------------------------------------------------------------ */
export type GenerationStatus =
    | 'REQUESTED'
    | 'PROCESSING'
    | 'COMPLETED'
    | 'FAILED';

/** 상태 업데이트 바디 */
export interface GenerationNotificationUpdateRequest {
    status: GenerationStatus;
    /** 변경된 썸네일 URL(선택) */
    thumbnailUrl?: string;
    /** 변경된 이미지·영상 개수(선택) */
    mediaCount?: number;
    /** 생성된 비디오 ID (선택) */
    videoId?: number;
    /** 실패 시 오류 메시지 (선택) */
    errorMessage?: string;
    /** 사용자 ID */
    userId: string;
}

/** 단건 응답 */
export interface GenerationNotificationResponse {
    id: number;
    title: string;
    thumbnailUrl: string;
    mediaCount: number;
    status: GenerationStatus;
    updatedAt: string; // ISO‑8601 문자열
    /** 생성된 비디오 ID (성공 시) */
    videoId?: number;
    /** 실패 시 오류 메시지 */
    errorMessage?: string;
}

/* ------------------------------------------------------------------
 * 서비스 클래스
 * ------------------------------------------------------------------ */
export class NotificationUpdateService {
    /** 백엔드 컨트롤러 base path */
    private static readonly BASE_PATH = '/notifications';

    /**
     * 상태/썸네일/개수 업데이트
     */
    static async updateNotification(
        id: number,
        request: GenerationNotificationUpdateRequest,
    ): Promise<GenerationNotificationResponse> {
        const internalToken = process.env.INTERNAL_API_TOKEN!;

        try {
            const { data } = await apiClient.put<GenerationNotificationResponse>(
                `${this.BASE_PATH}/${id}`,
                {
                    ...request,
                    userId: request.userId,
                },
                {
                    headers: {
                        'X-API-TOKEN': internalToken,
                    },
                }
            );
            return data;
        } catch (error: unknown) {
            const err = error as { response?: { status?: number } };
            if (err.response?.status === 401) {
                throw new Error('인증이 필요합니다. 내부 토큰을 확인해주세요.');
            }
            throw new Error('알림 상태 업데이트에 실패했습니다.');
        }
    }
}
