// src/app/internal/video/services/VideoStorageService.ts

import apiClient from '@/lib/api/apiClient'
import FormData from 'form-data'
import type { ReadStream } from 'fs'
import { NotificationUpdateService } from './NotificationUpdateService'

/**
 * 비디오 저장 요청 타입
 */
export interface VideoSaveRequest {
    prompt: string
    endpoint: string
    model: string
    videoName: string
    imageFile?: File | ReadStream | null
    videoUrl: string
    referenceUrl?: string
    activeTab?: 'image' | 'text' | 'video'
    userId: string
    notificationId?: number
}

/**
 * 비디오 저장 응답 타입
 */
export interface VideoSaveResponse {
    id: number
    name: string
    url: string
    createdAt: string
}

/**
 * URL을 통해 비디오를 서버에 저장하는 함수 (multipart/form-data)
 */
export async function saveVideoFromUrl(
    request: VideoSaveRequest
): Promise<VideoSaveResponse> {
    const maxRetries = 3
    let retryCount = 0
    const internalToken = process.env.INTERNAL_API_TOKEN!

    while (retryCount < maxRetries) {
        try {
            // FormData 구성
            const form = new FormData()
            form.append(
                'data',
                JSON.stringify({
                    prompt: request.prompt,
                    endpoint: request.endpoint,
                    model: request.model,
                    videoName: request.videoName,
                    videoUrl: request.videoUrl,
                    mode: request.activeTab === 'text' ? 'TEXT' : 'IMAGE',
                    referenceUrl: request.referenceUrl,
                    userId: request.userId,
                    notificationId: request.notificationId !== undefined ? request.notificationId.toString() : undefined,
                }),
                { contentType: 'application/json' }
            )

            if (request.imageFile) {
                form.append('referenceFile', request.imageFile)
            }

            const headers = {
                ...form.getHeaders(),
                'X-API-TOKEN': internalToken,
            }

            // multipart/form-data 요청
            const response = await apiClient.post<VideoSaveResponse>(
                '/my/videos/url',
                form,
                { headers }
            )

            // 비디오 저장 성공 시 알림 상태 업데이트
            if (request.notificationId) {
                try {
                    await NotificationUpdateService.updateNotification(request.notificationId, {
                        status: 'COMPLETED',
                        videoId: response.data.id,
                        thumbnailUrl: response.data.url,
                        userId: request.userId
                    })
                    console.log(`✅ 알림 상태 업데이트 성공: notificationId=${request.notificationId}, videoId=${response.data.id}`);
                } catch (error) {
                    console.error(`❌ 알림 상태 업데이트 실패: notificationId=${request.notificationId}`, error);
                    // 알림 업데이트 실패해도 비디오 저장은 성공이므로 진행
                }
            }

            return response.data
        } catch (error: unknown) {
            retryCount++

            const err = error as { response?: { status?: number } }
            if (err.response?.status === 401) {
                throw new Error('인증이 필요합니다. 내부 토큰을 확인해주세요.')
            }

            if (retryCount === maxRetries) {
                throw new Error(
                    '비디오 저장에 실패했습니다. 잠시 후 다시 시도해주세요.'
                )
            }

            // 점진적 백오프
            await new Promise((resolve) => setTimeout(resolve, 1000 * retryCount))
        }
    }

    throw new Error('비디오 저장에 실패했습니다.')
}
