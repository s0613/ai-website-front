// src/app/internal/video/services/VideoQueueService.ts

import { Queue } from 'bullmq';

//
// VideoJobData: 큐에 넣을 작업 데이터 타입
//
export interface VideoJobData {
    type: 'kling' | 'wan' | 'hunyuan' | 'veo2';
    prompt: string;
    imageUrl: string;
    userId: string;
    notificationId?: string;
    duration?: string;
    aspect_ratio?: string;
    seed?: number;
    enableSafetyChecker?: boolean;
    camera_control?: string;
    [key: string]: unknown;
}

const REDIS_URL: string = process.env.REDIS_URL ?? 'redis://localhost:6379';

export const videoQueue = new Queue<VideoJobData>(
    'video-generation',
    { connection: { url: REDIS_URL } }
);

export type JobStatusResponse =
    | { status: 'not_found' }
    | { status: string; result?: unknown };

export async function addVideoJob(
    type: VideoJobData['type'],
    data: VideoJobData
): Promise<string> {
    const job = await videoQueue.add(
        type,
        data,
        {
            attempts: 3,
            backoff: { type: 'exponential', delay: 1000 },
        }
    );
    return job.id ?? '';
}

export async function getJobStatus(jobId: string): Promise<JobStatusResponse> {
    const job = await videoQueue.getJob(jobId);
    if (!job) {
        return { status: 'not_found' };
    }
    const state = await job.getState();
    const result = job.returnvalue;
    return { status: state, result };
}
