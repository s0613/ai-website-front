// app/video/page.tsx
import VideoGenerationPage from "@/features/video/videoGeneration/components/VideoGenerationPage";

export default function VideoPage() {
  return <VideoGenerationPage />;
}
