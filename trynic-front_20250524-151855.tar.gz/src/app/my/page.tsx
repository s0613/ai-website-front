import CreationPage from "@/features/video/creation/CreationPage";

export default function Page() {
  return <CreationPage />;
}

