import FolderPage from "@/features/folder/FolderInPage";

export default FolderPage;
