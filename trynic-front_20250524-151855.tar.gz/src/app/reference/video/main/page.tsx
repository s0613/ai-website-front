import VideoReferencePage from "@/features/video/videoReference/main";

export default function Page() {
  return <VideoReferencePage />;
}
