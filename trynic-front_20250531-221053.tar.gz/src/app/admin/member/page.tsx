"use client";
import React from "react";
import MemberCheck from "@/features/admin/MemberCheck";

const MemberCheckPage = () => {
  return <MemberCheck />;
};

export default MemberCheckPage;
