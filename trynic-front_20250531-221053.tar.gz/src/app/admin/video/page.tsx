"use client";
import React from "react";
import VideoUpload from "@/features/video/VideoUploader";

const VideoUploadPage = () => {
  return <VideoUpload />;
};

export default VideoUploadPage;
