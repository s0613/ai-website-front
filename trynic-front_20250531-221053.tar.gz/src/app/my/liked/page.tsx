import MyLikedPage from "@/features/video/creation/MyLikedPage";

export default function Page() {
  return <MyLikedPage />;
}
