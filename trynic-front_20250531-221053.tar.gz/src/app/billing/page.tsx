"use client";

import React from "react";
import BillingPage from "@/features/payment/BillingPage";

export default function PaymentPage() {
  return <BillingPage />;
}
