import ImageReferencePage from "@/features/image/imageReference/ImageReferencePage";

export default function Page() {
  return <ImageReferencePage />;
}