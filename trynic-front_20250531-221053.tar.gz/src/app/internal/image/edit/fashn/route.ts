import { NextRequest, NextResponse } from "next/server";
import { fal } from "@fal-ai/client";

export const runtime = 'edge';

export async function POST(req: NextRequest) {
    try {
        // 런타임에 환경 변수 확인
        if (!process.env.FAL_KEY) {
            return NextResponse.json(
                {
                    error: "FAL_KEY 환경 변수가 설정되지 않았습니다.",
                },
                { status: 500 }
            );
        }

        fal.config({
            credentials: process.env.FAL_KEY,
        });

        const formData = await req.formData();
        const model_image_url = formData.get('model_image_url') as string;
        const garment_image_url = formData.get('garment_image_url') as string;
        const category = formData.get('category') as string || "auto";
        const mode = formData.get('mode') as string || "balanced";
        const garment_photo_type = formData.get('garment_photo_type') as string || "auto";
        const moderation_level = formData.get('moderation_level') as string || "permissive";
        const seed = Number(formData.get('seed')) || 42;
        const num_samples = Number(formData.get('num_samples')) || 1;
        const segmentation_free = formData.get('segmentation_free') !== 'false';

        console.log('Received params:', {
            model_image_url,
            garment_image_url,
            category,
            mode,
            garment_photo_type
        });

        // 필수 파라미터 검증
        if (!model_image_url || !garment_image_url) {
            return NextResponse.json(
                { error: "model_image_url and garment_image_url are required" },
                { status: 400 }
            );
        }

        // category 유효성 검증
        const validCategories = ["tops", "bottoms", "one-pieces", "auto"];
        if (!validCategories.includes(category)) {
            return NextResponse.json(
                { error: "Invalid category. Must be one of: tops, bottoms, one-pieces, auto" },
                { status: 400 }
            );
        }

        // Fashn API 호출
        const result = await fal.subscribe("fal-ai/fashn/tryon/v1.5", {
            input: {
                model_image: model_image_url,
                garment_image: garment_image_url,
                category,
                mode,
                garment_photo_type,
                moderation_level,
                seed,
                num_samples,
                segmentation_free,
            },
            logs: true,
            onQueueUpdate: (update) => {
                if (update.status === "IN_PROGRESS") {
                    console.log(update.logs.map((log) => log.message));
                }
            },
        });

        // 결과 이미지 URL 반환
        return NextResponse.json({
            success: true,
            imageUrl: result.data.images[0]  // 첫 번째 생성된 이미지 URL 반환
        });
    } catch (error) {
        console.error("Error in image generation:", error);
        let errorMsg = "Failed to generate image";
        // ValidationError 등에서 body.detail[0].msg 추출
        if (error && typeof error === 'object') {
            const errObj = error as { body?: { detail?: { msg?: string }[] }, message?: string, toString?: () => string };
            if (errObj.body && Array.isArray(errObj.body.detail) && errObj.body.detail[0]?.msg) {
                errorMsg = errObj.body.detail[0].msg!;
            } else if (typeof errObj.message === 'string') {
                errorMsg = errObj.message;
            } else if (typeof errObj.toString === 'function') {
                errorMsg = errObj.toString();
            }
        } else if (typeof error === 'string') {
            errorMsg = error;
        }
        return NextResponse.json(
            { error: errorMsg, details: error },
            { status: 500 }
        );
    }
}
