import React from "react";
import Login from "@/features/user/forms/Login";

const LoginPage = () => {
  return <Login />;
};

export default LoginPage;
