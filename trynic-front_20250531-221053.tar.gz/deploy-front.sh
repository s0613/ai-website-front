#!/bin/bash
set -euo pipefail

########################################################
# 0) 기본 설정
########################################################
SSH_USER="ec2-user"
SSH_HOST="15.164.142.98"
SSH_KEY_PATH="/Users/songseungju/Desktop/CrazySpace/trynickey.pem"

REMOTE_BASE_DIR="/home/ec2-user/trynic-front"
APP_NAME="trynic-front"
WORKER_NAME="video-worker"

########################################################
# 1) macOS 리소스 포크 파일 삭제
########################################################
echo "[CLEANUP] macOS '._*' 파일 제거"
find . -type f -name '._*' -delete || true

########################################################
# 2) 번들 압축 (리소스 포크 완전 비포함)
########################################################
TS=$(date '+%Y%m%d-%H%M%S')
BUNDLE="trynic-front_${TS}.tar.gz"
echo "[PACK] 소스 코드 압축 (env·빌드 결과·리소스포크 제외)"

# COPYFILE_DISABLE=1 : AppleDouble 파일 차단
# --disable-copyfile  : BSD tar 확장 속성 무시
COPYFILE_DISABLE=1 tar --no-xattrs --disable-copyfile -czf "$BUNDLE" \
  --exclude="$BUNDLE" \
  --exclude='.next' \
  --exclude='node_modules' \
  --exclude='.git' \
  --exclude='.env*' \
  --exclude='**/._*' \
  .
echo "[PACK] ✔  $BUNDLE 생성 완료"

########################################################
# 3) 원격 전송
########################################################
echo "[SEND] $BUNDLE → $SSH_USER@$SSH_HOST:$REMOTE_BASE_DIR"
SSH_OPT=(); [ -f "$SSH_KEY_PATH" ] && SSH_OPT=(-i "$SSH_KEY_PATH")

ssh "${SSH_OPT[@]}" "$SSH_USER@$SSH_HOST" "mkdir -p $REMOTE_BASE_DIR"
scp "${SSH_OPT[@]}" "$BUNDLE" "$SSH_USER@$SSH_HOST:$REMOTE_BASE_DIR/"
[ -f .env.production ] && scp "${SSH_OPT[@]}" .env.production "$SSH_USER@$SSH_HOST:$REMOTE_BASE_DIR/"

########################################################
# 4) 원격 배포 및 기동
########################################################
ssh "${SSH_OPT[@]}" "$SSH_USER@$SSH_HOST" bash << EOS
set -euo pipefail

REMOTE_DIR="/home/ec2-user/trynic-front"
APP_NAME="trynic-front"
WORKER_NAME="video-worker"

# 4-1) 최신 번들 선정 (가장 최근 수정 시각 파일 1개)
LATEST_BUNDLE=\$(ls -1t "\$REMOTE_DIR"/trynic-front_*.tar.gz | head -n1)
echo "[REMOTE] 최신 번들: \$LATEST_BUNDLE"

# 4-2) PM2 기존 프로세스 종료
if command -v pm2 &>/dev/null; then
  pm2 delete "\$APP_NAME" || true
  pm2 delete "\$WORKER_NAME" || true
  sleep 1
fi

# 4-3) 기존 배포 백업
if [ -d "\$REMOTE_DIR/current" ]; then
  BACKUP="\$REMOTE_DIR/backup_\$(date '+%Y%m%d-%H%M%S')"
  sudo mv "\$REMOTE_DIR/current" "\$BACKUP"
  echo "[REMOTE] 백업: \$BACKUP"
fi
sudo mkdir -p "\$REMOTE_DIR/current"
sudo chown ec2-user:ec2-user "\$REMOTE_DIR/current"

# 4-4) 압축 해제
tar -xzf "\$LATEST_BUNDLE" -C "\$REMOTE_DIR/current"
cd "\$REMOTE_DIR/current"

# 4-5) env 로드 (.env.production이 있다면 현재 디렉토리로 복사)
if [ -f "\$REMOTE_DIR/.env.production" ]; then
  cp "\$REMOTE_DIR/.env.production" .
  echo "[REMOTE] .env.production 파일 복사 완료"
fi

# 4-6) Node/npm/PM2 설치
command -v node &>/dev/null || sudo yum -y install nodejs
command -v npm  &>/dev/null || { echo "npm 미설치" >&2; exit 1; }
command -v pm2 &>/dev/null || sudo npm install -g pm2

# 4-7) 의존성 설치 및 빌드 (환경 변수 포함)
npm ci
npm run build

# 4-8) PM2 기동 (환경 변수 다시 로드)
[ -f .env.production ] && { set -o allexport; source .env.production; set +o allexport; }
pm2 start npm --name "\$APP_NAME"   -- start       --update-env
pm2 start npm --name "\$WORKER_NAME" -- run worker --update-env
pm2 save

# 4-9) Nginx 리로드
sudo systemctl reload nginx

# 4-10) 번들·백업 정리 (5개만 유지)
cd "\$REMOTE_DIR"
ls -1t trynic-front_*.tar.gz | tail -n +6 | xargs -r rm -f
ls -1dt backup_*             | tail -n +6 | xargs -r rm -rf

echo "[REMOTE] 배포 완료 🎉"
EOS

########################################################
# 5) 로컬 번들 삭제
########################################################
rm -f "$BUNDLE"
echo "✅  배포 스크립트 완료"
