// 프로필 응답 타입 정의
export interface ProfileResponse {
  success: boolean;
  message?: string;
  nickname?: string;
}