import PaymentForm from "@/features/payment/PaymentForm";

export default function PaymentPage() {
  return <PaymentForm />;
}
