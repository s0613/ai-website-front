import SettingPage from "@/features/my/SettingPage";

export default function Page() {
  return <SettingPage />;
}
