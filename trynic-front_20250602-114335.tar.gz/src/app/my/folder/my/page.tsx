import MyFolderPage from "@/features/folder/MyFolderPage";

export default function Page() {
  return <MyFolderPage />;
}
