import EditImagePage from "@/features/image/FashnImagePage";

export default function EditPage() {
    return <EditImagePage />;
}
