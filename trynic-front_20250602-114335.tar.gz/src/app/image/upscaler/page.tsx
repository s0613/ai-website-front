import UpscalerImagePage from "@/features/image/UpscalerImagePage";

export default function ImageUpscalerPage() {
    return <UpscalerImagePage />;
}
