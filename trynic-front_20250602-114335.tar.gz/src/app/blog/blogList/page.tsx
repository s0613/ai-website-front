import BlogList from "@/features/blog/BlogList";

const BlogPage = () => {
  return (
    <div>
      <BlogList />
    </div>
  );
};

export default BlogPage;
