import NotificationSend from "@/features/admin/NotificationSend";

export default function NotificationPage() {
  return <NotificationSend />;
}
