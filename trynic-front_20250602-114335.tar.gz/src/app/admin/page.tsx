import React from "react";
import Home from "@/features/admin/Home";

export default function AdminHomePage() {
  return <Home />;
}
